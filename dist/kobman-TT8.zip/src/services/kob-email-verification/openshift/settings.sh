export PROJECT_NAMESPACE="devex-von-image"
export GIT_URI="https://github.com/bcgov/indy-email-verification.git"
export GIT_REF="master"

# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
# Override environments, since there is only one AT THE MOMENT:
# devex-von-image-tools
# !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
export TOOLS="devex-von-image-tools"
export DEPLOYMENT_ENV_NAME="tools"
export DEV="tools"
export TEST="tools"
export PROD="tools"