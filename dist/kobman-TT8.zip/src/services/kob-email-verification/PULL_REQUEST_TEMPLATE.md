
### To raise a new Pull Request, the following prerequisites need to be met. Please tick before proceeding:


- [ ] a conversation was held in the appropriate media [hyperledgerkochi](https://github.com/orgs/hyperledgerkochi/projects/3) channel.
- [ ] a Github [Issue](https://github.com/hyperledgerkochi/KOBman/issues) was opened for this feature / bug.


____________________________________________________________________________________

**This addresses Issue** #XXX-Link-to-Approved-Issue-XXX
